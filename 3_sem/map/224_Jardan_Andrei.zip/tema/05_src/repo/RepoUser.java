package repo;

import domain.User;

import java.util.UUID;

abstract public class RepoUser implements Repo<User, UUID> {
}
