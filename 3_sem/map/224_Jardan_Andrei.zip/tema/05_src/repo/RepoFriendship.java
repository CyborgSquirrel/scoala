package repo;

import domain.Friendship;
import domain.FriendshipId;

abstract public class RepoFriendship implements Repo<Friendship, FriendshipId> {
}
