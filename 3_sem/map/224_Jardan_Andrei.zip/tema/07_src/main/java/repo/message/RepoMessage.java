package repo.message;

import domain.Message;
import repo.Repo;

import java.util.UUID;

public abstract class RepoMessage implements Repo<Message, UUID> {
}
