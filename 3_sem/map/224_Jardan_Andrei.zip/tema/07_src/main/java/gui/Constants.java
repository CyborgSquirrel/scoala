package gui;

public class Constants {
    public static double sceneWidth = 500;
    public static double sceneHeight = 400;
}
