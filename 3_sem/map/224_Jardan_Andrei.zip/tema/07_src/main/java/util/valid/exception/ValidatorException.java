package util.valid.exception;

public class ValidatorException extends RuntimeException { }
