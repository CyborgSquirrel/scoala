package util.valid.exception;

public class InvalidNameException extends ValidatorException { }
