package repo;

public class ItemAlreadyExistsException extends Exception {
}
