package repo;

public class ItemDoesntExistException extends Exception {
}
