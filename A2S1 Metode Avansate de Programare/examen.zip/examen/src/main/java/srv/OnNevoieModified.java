package srv;

@FunctionalInterface
public interface OnNevoieModified {
    void callback();
}
