package gui;

public class Util {
    final static int WIDTH = 500;
    final static int HEIGHT = 500;
}
